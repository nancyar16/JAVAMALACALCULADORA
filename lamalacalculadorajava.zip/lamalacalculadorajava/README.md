BadCalcVeryBadJava

This Java project is intentionally full of terrible programming practices for classroom exercises.
Do NOT use in production.

Features:

How to build:
mvn -q -DskipTests package
java -cp target/BadCalcVeryBadJava-1.0-SNAPSHOT.jar com.example.badcalc.Main

